This folder containts all files contained within .fla project for Flash hitbox.

Those files are placed here for all interested people who don't have Adobe Flash Professional.

Original source was made in Macromedia Flash Professional 8 by Stormtrooper.

---

# Help Needed
<img align="right" src="https://user-images.githubusercontent.com/4959837/119581446-d92f6880-bdc2-11eb-8575-4e1a27895905.png">
We would appreciate if somebody could port this hitbox from Flash to a more modern web standard because Flash player has reached its End Of Life.
Right now, Flash hitbox is displayed by using flash emulator, but we would like to change that.

 
Thank you.
