#!/usr/bin/perl 
# Converts an OpenGL.h header file into an Actionscript.as file for my own needs.
# -- Stormtrooper

use strict;
use warnings;
use Data::Dumper;

use constant X => 0;
use constant Y => 1;
use constant Z => 2;
use constant SCALE => 1.25;

my $infile = $ARGV[0] || "basicman.h" || die "Must give a filename to convert";
my $outfile = ((split(/\./,$infile))[0]) . ".as";

open(I, $infile) || die "Error opening $infile: $!";
open(O, ">$outfile") || die "Error opening $outfile: $!";

my $key = '';
my $type = '';
my $data = {};

while (my $line = <I>) {
	$line =~ s/^\s+//;
	$line =~ s/\s+$//;
	next unless $line;

	if (!$type) { 
		if ($line =~ /^Point3 ([\w\d_]+)_(vertex|normal)/) {
			$key = $1;
			$type = $2;
			next;
		} elsif ($line =~ /^long ([\w\d_]+)_([nv]idx)/) {
			$key = $1;
			$type = $2;
			next;
		}
	} elsif ($line =~ /^\}/) {
		$key = '';
		$type = '';
		next;
	}
	$line =~ tr/,\{\}/ /;	# remove stuff
	$line =~ s/^\s+//;
	$line =~ s/\s+$//;
	next unless ($key and $type) and $line;

	$key =~ s/_//;		# remove underscores from key names

	push(@{$data->{$key}{$type}}, $type =~ /vertex|normal/ ? [ map { $_ * SCALE } (split(/\s+/, $line)) ] : split(/\s+/, $line) );
#	my @values = (map { $_ * SCALE } split(/\s+/, $line));
#	if ($type =~ /vertex|normal/) {
#		push(@{$data->{$key}{$type}}, [ @values ]);
#	} else {
#		push(@{$data->{$key}{$type}}, @values);
#	}
}
close(I);

my @types = sort keys %$data;
my ($x,$y,$z,$x2,$y2,$z2);

foreach my $t (@types) {
	my $vert = $data->{$t}{vertex};
	my $norm = $data->{$t}{normal};
	my $vidx = $data->{$t}{vidx};
	my $nidx = $data->{$t}{nidx};

	print "$t \n";
	print "\t", scalar @$vert, " vertexes\n";
	print "\t", scalar @$vidx, " vertex idx\n";

	for (my $i=0; $i<@$vidx; $i+=3) {
		my $v1 = [ @{$vert->[$vidx->[$i  ]]} ];
		my $v2 = [ @{$vert->[$vidx->[$i+1]]} ];
		my $v3 = [ @{$vert->[$vidx->[$i+2]]} ];
		my $f  = [$v1,$v2,$v3];
		my $fn = norm($v1, $v3);

		push(@{$data->{$t}{faces}}, [$v1,$v2,$v3]);
		push(@{$data->{$t}{fnormals}}, [ norm($v1, $v3) ]);
	}
}

foreach my $t (@types) {
	my $verts = $data->{$t}{vertex} || next;
	my $vidx  = $data->{$t}{vidx} || next;
	my $norms = $data->{$t}{fnormals} || next;
#	my $faces = $data->{$t}{faces} || next;

	print O "var ${t}_vertex:Array = Array(\n";
	for (my $i=0; $i<@$verts; $i++) {
		print O "\tnew Vertex(" . join(',',@{$verts->[$i]}) . ")";
		print O "," if $i+1 < @$verts;
		print O "\n";
		
	}
	print O ");\n\n";

	print O "var ${t}_vidx:Array = Array(\n";
	print O "\t// every 3 indexes makes a face from the ${t}_vertex array\n\t";
	my $i = 0;
	print O map { (++$i % 21 != 0) ? ($i<@$vidx ? "$_," : "$_\n") : ($i<@$vidx) ? "$_,\n\t" : "$_\n" } @$vidx;
	print O ");\n\n";

	print O "var ${t}_fnormals:Array = Array(\n";
	print O "\t// every vertex is a face normal (normalized) for 3 vertexes in ${t}_vertex array\n";
	for (my $i=0; $i<@$norms; $i++) {
		print O "\tnew Vertex(" . join(',',@{$norms->[$i]}) . ")";
		print O "," if $i+1 < @$norms;
		print O "\n";
		
	}
	print O ");\n\n";
}

close(O);

exit;


# --------------------------------------
# returns the cross product (1 vertex) between 2 vectors
sub cross {
	my ($v1, $v2) = @_;
	my ($x,$y,$z);
	$x = $v1->[Y] * $v2->[Z] - $v1->[Z] * $v2->[Y];		# y1 * z2 - z1 * y2
	$y = $v1->[Z] * $v2->[X] - $v1->[X] * $v2->[Z];		# z1 * x2 - x1 * z2
	$z = $v1->[X] * $v2->[Y] - $v1->[Y] * $v2->[X];		# x1 * y2 - y1 * x2
	return wantarray ? ($x,$y,$z) : [$x,$y,$z];
}

# length (magnitude of a vertex)
sub len {
	my ($x,$y,$z) = @_;
	return sqrt(($x * $x) + ($y * $y) + ($z * $z));
}

# return a surface normal vertex from 2 vertexes
sub norm {
	my ($v1, $v2) = @_;
	my ($x,$y,$z) = cross($v1, $v2);
	my $len = len($x,$y,$z);
	$x /= $len;
	$y /= $len;
	$z /= $len;
	return wantarray ? ($x,$y,$z) : [$x,$y,$z];
}