This is the original source for the flash 8 project for the PsychoStats v3.0 3D hitbox.

Using Flash 8, open the HITBOX.flp project and the environment will be loaded.

The 'model' directory contains the basic model that was used. Files in this directory include:
	basicman.as
		ActionScript file that gets included into the flash that defines the model.
	basicman.h
		OpenGL C++ header file that was exported from a 3D app. This contains the model
		meshes and normals, etc.
	conv.pl
		This perl script will read an OpenGL C++ header file and convert it to an 
		ActionScript file. By default it reads "basicman.h". In order for a model to 
		properly be loaded by the hitbox flash the model must have 7 meshes defined. 
		One for each hitgroup: head, chest, stomach, leftarm, rightarm, leftleg, rightleg.

The 'xml' directory contains a couple of test files that are used while working on the flash locally. These files are mockups of what the flash reads for a player in the stats.

Everything else make up the flash animation itself. 3D routines, preloaders, the hitbox itself.