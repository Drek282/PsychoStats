<?
// MySQL-Server-Address
$sqlhost="localhost";
// MySQL-Username
$sqluser="mymysqlname";
// MySQL-Password
$sqlpass="mymysqlpassword";
// MySQL-Database
$database="mymysqldatabase";
//Site Personal Stats
$urlp="http://www.wing-clan.de/psstats/player.php?id=";
//Site Global Stats
$urlr="http://www.wing-clan.de/psstats/index.php";
?>
