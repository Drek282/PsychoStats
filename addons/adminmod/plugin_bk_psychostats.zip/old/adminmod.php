<?
require("configadminmod.php");
$serverid=mysql_connect($sqlhost, $sqluser, $sqlpass);
echo mysql_error($serverid);

if (!mysql_select_db($database)){
    echo mysql_error($serverid);
    die ("Kein Zugriff auf Datenbank!");
}

$sqlabfrage="SELECT plrid FROM pstats_plr WHERE worldid='$id'";
$result=mysql_db_query($database,$sqlabfrage);
$row = mysql_fetch_array ($result);
if($row["plrid"]=="" || $site=="1"){
	$url=$urlr;
}
else {
	$url=$urlp.$row["plrid"];
}
mysql_close($serverid);
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0; url=<? echo $url ?>">
</head>
</html>