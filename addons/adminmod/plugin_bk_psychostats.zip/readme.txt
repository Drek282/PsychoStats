BK's Psychostats Plugin v1.1 for Admin Mod

-----------------------------------------------------------------------------
English:

Opens the Psychostats 2.x in the MOTD window via chat or console.

Features:
- Free configuration of signal words, so it won't interfere with other plugins like statsme, etc.
- Differs between global and personal stats depending on the signal word
- Can also show stats of other people, when part of the name is given after the signal word as an option
- Easy configuration
- Can be easily made compatible with PS 2.0 and 2.1 beta
- Stats can also be issued via console command

Requirements:
Admin Mod 2.50.59 and higher
Psychostats 2 beta 0 or higher

Installation:
Compile and install the plugin
Do a mapchange in order to initialize the plugin.

Additional steps for older PS versions:
I don't know, if it works with PS 2.1 or 2.0 that way, so I still include the old way, how to access the personal stats. If you run into troubles with a previous version of psychostats, do this:
Go to the "old" directory in this plugin distribution and edit the configadminmod.php so it meets your needs and move it, including the adminmod.php, to your webserver. For PS 2.0 you have to change in the configadminmod.php "player.php?id=" to "index.php?page=plr&id=", additionally.
Furthermore, the plugin has to be recompiled with "#OLD 1". Edit the sma file for that purpose.

Configuration:
You need access level 512 in order to change the settings.
Configuration is done by admin_ps_set <option> <value>. Omitting the value parameter will display the actual value, omitting all will display all available options, which are:
PREFIX: Sets the signal character. Usually this is "." or "/", so you say "/stats" or ".stats" in the chat. If the character is not in the actual list, it will be added otherwise deleted. There are up to 10 signal characters allowed.
STATSME: Sets the signal word for personal stats. Usually this is "stats" or "statsme", so you say "/stats" or "/statsme" in the chat. If the word is not in the actual list, it will be added otherwise deleted. There are up to 10 signal words allowed.
RANK: Sets the signal word for overall stats. Usually this is "rank" or "top10", so you say "/rank" or "/top10" in the chat. If the word is not in the actual list, it will be added otherwise deleted. There are up to 10 signal words allowed.
URL: Specify the url here, where to find the index.php. Remember to include the index.php in that string! If you use the old way, it is the adminmod.php here.

Usage:
Type the signal word in the chat and see your stats or the global ones. Put the part of the name of an also playing friend after the signal word to see his/her stats. You can also see the stats of offline players by appending their ID (WON/Steam). Last but not least, you can use admin_stats to open the stats.

That's it. Please be aware that checking might take some time.

Have fun.

Check http://www.wing-clan.de and http://www.admin-mod.de for more.

Changelog:
1.1	[Fix] Signal words for other plugin with the same prefix were not passed through (bug found by Sir Drink a lot).
		[Fix] Typo in name converting, producing errors for every saying a person did who had a name length of 31. (bug found by Old and Slow).
		[New] Webserver php files are no longer needed
1.0	First version

-----------------------------------------------------------------------------
Deutsch:

�ffnet Psychostats 2.x im MOTD-Window per chat bzw. Console.

Features:
- Freie Konfiguration der Signalw�rter, so dass diese nicht mit anderen Plugins wie Statsme kollidieren.
- Unterscheidet zwischen globalen und pers�nlichen Statistiken je nach Signalwort.
- Kann auch die Statistiken anderer Spieler zeigen, wenn ihr ein Teil des Namens nach Signalwort als Option angegeben wurde.
- Einfache Konfiguration
- Kann kompatibel zu PS 2.0 und 2.1 beta gemacht werden.
- Die Statistik kann auch per Consolen-Befehl aufgerufen werden.

Anforderungen:
Admin Mod 2.50.59 oder neuer
Psychostats 2 beta 0 oder neuer

Installation:
Compiliere und installiere das Plugin
F�hre einen Mapwechsel durch, um das Plugin zu starten.

Zus�tzliche Schritte f�r �ltere PS Versionen:
Ich wei� nicht, ob dies direkt auch mit PS 2.1 und 2.0 funktioniert. Daher habe ich auch die alte Methode noch zur Verf�gung gestellt. Wenn irgendwelche Probleme mit �lteren PS versionen auftreten, sollte folgendes gemacht werden:
Gehe ins "old" Verzeichnis, das in dieser Plugindistribution zu finden ist und editiere die configadminmod.php, so dass sie den eigenen W�nschen entspricht, und lade sie inklusive der adminmod.php auf den Webserver. F�r PS 2.0 muss in der configadminmod.php noch "player.php?id=" in "index.php?page=plr&id=" ge�ndert werden.
Au�erdem muss das Plugin mit "#OLD 1" neu compiliert werden. Daf�r zuvor die sma-Datei editieren.

Konfiguration:
Du ben�tigst Access Level 512, um die Einstellungen zu �ndern.
Die Konfiguration wird mittel admin_ps_set <Option> <Wert> durchgef�hrt. L�sst man den Wert weg, wird der aktuelle Wert der Option angezeigt, l�sst man alles weg, werden alle m�glichen Optionen angezeigt, welche w�ren:
PREFIX: Legt die Signalbuchstaben fest. Normalerweise ist dies "." oder "/", so dass man im Chat "/stats" oder ".stats" sagt. Ist ein Buchstabe nicht in der aktuellen Liste, wird er hinzugef�gt anderenfalls gel�scht. Es k�nnen bis zu zehn Signalbuchstaben eingegeben werden.
STATSME: Legt die Signalw�rter f�r die pers�nliche Statistik fest. Normalerweise sind dies "stats" oder "statsme", so dass man im Chat "/stats" oder "/statsme" sagt. Ist ein Wort nicht in der aktuellen Liste, wird es hinzugef�gt anderenfalls gel�scht. Es k�nnen bis zu zehn Signalw�rter eingegeben werden.
RANK: Legt die Signalw�rter f�r die globale Statistik fest. Normalerweise sind dies "rank" oder "top10", so dass man im Chat "/rank" oder "/top10" sagt. Ist ein Wort nicht in der aktuellen Liste, wird es hinzugef�gt anderenfalls gel�scht. Es k�nnen bis zu zehn Signalw�rter eingegeben werden.
URL: Spezifiziere hier die URL, wo sich die adminmod.php befindet. Vergesse nicht die adminmod.php selbst anzuh�ngen!

Benutzung:
Schreibe ein Signalwort im Chat um Deine eigenen oder die globalen Stats zu sehen. Schreib einen Teil des Namens eines Freundes hinter das Signalwort, um seine Statistik zu Gesicht zu bekommen. Du kannst auch Spieler nachschauen, wenn sie offline sind, wenn Du stattdessen ihre ID (WON/Steam) angibst. Zu guter letzt kannst Du die Statistik auch �ber admin_stats aufrufen.

Das ist es schon. Bitte ber�cksichtige, dass der Aufruf der Seite etwas dauern kann.

Ich w�nsche viel Spa�

Besucht auch http://www.wing-clan.de und http://www.admin-mod.de f�r mehr Information.

Changelog:
1.1	[Fix] Signalw�rter f�r andere Plugins mit dem gleichen Signalbuchstaben wurden nicht durchgelassen (Bug von Sir Drink a lot gefunden).
		[Fix] Falsche Arraygr��e in der Namenskonvertierung verursachte Fehler bei jeder Verwendung von "say" bei Spieler, deren Namen 31 Zeichen lang war (Bug von Old and Slow gefunden).
		[Neu] Die PHP-Dateien f�r den Webserver werden nicht mehr ben�tigt.
1.0	First version